from odoo import fields, models


class EstateWizard(models.TransientModel):
    _name = 'estate.wizard'
    _description = 'Estate Wizard'

    partner_id = fields.Many2one('res.partner')
    price = fields.Float()
    property_type_id = fields.Many2one('estate.property')


    def action_make_offer(self):
        pass